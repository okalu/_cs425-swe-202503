package edu.miu.cs.cs425.citylibraryapp;

import edu.miu.cs.cs425.citylibraryapp.model.Publisher;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import edu.miu.cs.cs425.citylibraryapp.service.PublisherService;

@SpringBootApplication
public class CitylibrarycliappV1Application { //implements CommandLineRunner {

	private final PublisherService publisherService;

	public CitylibrarycliappV1Application(PublisherService publisherService) {
		this.publisherService = publisherService;
	}

	public static void main(String[] args) {
		SpringApplication.run(CitylibrarycliappV1Application.class, args);
	}

//	@Override
//	public void run(String... args) throws Exception {
//		System.out.println("Hello World of Spring Boot!");
//	}

	@Bean
	CommandLineRunner commandLineRunner() {
		return args -> {
			System.out.println("Hello World of Spring Boot!");
			registerNewPublisher("Addison-Wesley, Inc.", "sales@adw.com", "(242) 272-0987");

			System.out.println("List of Publishers");
			getAndPrintAllPublishers();
		};
	}

	private void getAndPrintAllPublishers() {
		var publishers =  publisherService.getAllPublishers();
		publishers.forEach(System.out::println);
	}

	private void registerNewPublisher(String name, String  email, String phoneNumber) {
		var newPublisher = new Publisher(null, name, email, phoneNumber);
		var savedPublisher = publisherService.registerNewPublisher(newPublisher);
		System.out.printf("New Publisher created.\n", savedPublisher);
	}

	private void fetchAndUpdatePublisherById(Integer id, String name, String email, String phoneNumber) {
		var publisher = publisherService.getPublisherById(id);
		if(publisher != null) {
			publisher.setName(name);
			publisher.setEmail(email);
			publisher.setPhoneNumber(phoneNumber);
			var updatedPublisher = publisherService.updatePublisher(publisher);
			System.out.printf("Updated Publisher:\n%s", updatedPublisher);
		}
	}
}
