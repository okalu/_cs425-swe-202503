package edu.miu.cs.cs425.citylibraryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CitylibrarycliappV1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
